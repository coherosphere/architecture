# Coherosphere — Event Schemas (v2)

- Base URL for `$id`: `https://schemas.coherosphere.io/events/`
- Draft: JSON Schema 2020-12
- Shared fragments live in `_meta/common.json`

Naming convention: `<domain>/<EventName>.v<major>.json`
